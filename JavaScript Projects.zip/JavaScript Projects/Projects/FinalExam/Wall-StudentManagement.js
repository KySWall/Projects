// Establish array
let studentList = []

// Add student to list if their name and GPA pass through
function addStudent()
{
  // Gets the inputted name and gpa 
  let getName = document.getElementById('nameInput').value;
  let getGPA = parseFloat(document.getElementById('gpaInput').value);

  if (getName && !isNaN(getGPA) && getGPA >= 0 && getGPA <= 5)
  {
    studentList.push({getName, getGPA});
    document.getElementById('nameInput').value = '';
    document.getElementById('gpaInput').value = '';
    displayStudent();
  }
  else
  {
    alert('Please enter a valid name or GPA')
  }
}

// Removes last student that was added to the list
function removeLastStudent()
{
  if (studentList.length > 0){
    let newStudents = []
    for (let i = 0; i < studentList.length - 1; i++){
      newStudents.push(studentList[i]);
    }
    studentList = newStudents;
    displayStudent();
  }
  else{
    alert('No students to remove')
  }
}
// Function to remove student in accordence with the number(index) beside the student 
function removeStudent()
{
  let studentNum = parseInt(document.getElementById('remove').value);
  
  if (!isNaN(studentNum) && studentNum >= 0 && studentNum < studentList.length){
    let newStudents = []
    for (let i = 0; i < studentList.length; i++){
      if (i !== studentNum){
        newStudents.push(studentList[i])
      }}
    studentList = newStudents;
    displayStudent();
  }
  else{
    alert('Please enter a valid student to remove.')
  }
}

// Fucntion to calculate average gpa
function calculateGPA()
{
  if (studentList.length > 0)
  { 
    let totalGPA = 0
    for (let i = 0; i < studentList.length; i++)
    {
      totalGPA += studentList[i].getGPA
    }

    let averageGPA = totalGPA / studentList.length;

    alert(`The Average GPA of the students is ${averageGPA.toFixed(2)}`);
  }
  else
  {
    alert('There are no students to calculate GPA')
  }
}

// Fuction to update and display the students
function displayStudent()
{
  let studentDisplay = '';
  for (let i = 0; i < studentList.length; i++)
  {
    studentDisplay += `${i} - ${studentList[i].getName} - GPA: ${studentList[i].getGPA}<br>`;
  }
  document.getElementById('output').innerHTML = studentDisplay;
}