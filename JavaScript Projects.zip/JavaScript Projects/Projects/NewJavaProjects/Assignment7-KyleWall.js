// JavaScript Code

// This snippet resets the calculator everytime it starts
localStorage.removeItem('userInput');

let calculations =''

let userInputDisplay = document.getElementById('userInputDisplay')

displayUserInput();


function updateUserInput(value)
{ // Function that updates the user's input when a button is clicked
    calculations += value;

    displayUserInput();

    localStorage.setItem('userInput', calculations);
}

function displayUserInput()
{   // Fucntions that displays the user inputted calculations, actual calculations are done in HTML with 'eval'
    userInputDisplay.innerHTML = calculations;
}