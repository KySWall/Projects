let toDoList = ['Make Dinner', 'Watch Youtube', 'Study for Final'];

renderList();

function renderList()
{
  let toDoHTML = '';

  for (let i = 0; i < toDoList.length; i++)
  {
    const toDo = toDoList[i];
    let html = `<p>${toDo}</p>`;
    toDoHTML += html;
  }
  document.querySelector('.js-todo-list').innerHTML = toDoHTML;
}

// looping through the array
for (let i = 0; i < toDoList.length; i++)
{
  console.log(toDoList[i]);
}

function addItem()
{
  const inputElement = document.getElementById('input-element');
  toDoList.push(inputElement.value);
  console.log(toDoList);
  inputElement.value = '';
  renderList();
}