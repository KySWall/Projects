// Script runs after html is fully loaded
document.addEventListener('DOMContentLoaded', function()
{
    // Intialize typed.js
    let typed = new Typed(".changingIntroText", {
        // Differnt intros
        strings: ["Hello!", "Howdy! Howdy!", "Greetings!", "Pleased to meet you!", "Hi there!", "It's a pleasure!"],
        // Parameters
        typeSpeed: 100,
        backSpeed: 100,
        backDelay: 1000,
        loop: true
    });
});

// Script to make the navigation bar disappear when the user scrolls down.
var prevScrollpos = window.pageYOffset;

window.addEventListener('scroll', function() 
{
    var currentScrollPos = window.pageYOffset; // Keep track of the position on the screen
    const navBar = document.querySelector('.navBar'); // Grab the navBar
    const logo = document.querySelector('.logo');

    if (prevScrollpos > currentScrollPos) 
    {
        // User is scrolling up, show the navbar
        navBar.classList.remove('hidden');
        logo.classList.remove('hidden');
    } 
    else 
    {
        // User is scrolling down, hide the navbar
        navBar.classList.add('hidden');
        logo.classList.add('hidden');
    }

    prevScrollpos = currentScrollPos;
});


//Function for project showcase 1
function galleryShowcase1(img) 
{
    // Get the expanded image
    var viewedImage1 = document.getElementById("viewedImage1");
    // Get the image text
    var imageText1 = document.getElementById("imageText1");
    viewedImage1.src = img.src;
    // alt attribute as image text
    imageText1.innerHTML = img.alt;
    // Show the container element (hidden with CSS)
    document.querySelector('.project1 .showcaseContainer').style.display = "block";
}
//Function for project showcase 2
function galleryShowcase2(img) 
{
    // Get the expanded image
    var viewedImage2 = document.getElementById("viewedImage2");
    // Get the image text
    var imageText2 = document.getElementById("imageText2");
    viewedImage2.src = img.src;
    // alt attribute as image text
    imageText2.innerHTML = img.alt;
    // Show the container element (hidden with CSS)
    document.querySelector('.project2 .showcaseContainer').style.display = "block";
}
//Function for project showcase 3
function galleryShowcase3(img) 
{
    // Get the expanded image
    var viewedImage3 = document.getElementById("viewedImage3");
    // Get the image text
    var imageText3 = document.getElementById("imageText3");
    viewedImage3.src = img.src;
    // alt attribute as image text
    imageText3.innerHTML = img.alt;
    // Show the container element (hidden with CSS)
    document.querySelector('.project3 .showcaseContainer').style.display = "block";
}

function confirmDownload(url) 
{
    if (confirm("Are you sure you want to download?")) 
    {
        window.open(url);
    }
}