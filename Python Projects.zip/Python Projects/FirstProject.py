#FirstProject
#Kyle Wall (08/24/2022)
#Basic use of the print() function 
print("Kyle Wall")
print("2224 Wellesley Drive")
print("Lima, Ohio 45804")
print("586.404.2661")
print("Web/Copmuter Programming")
