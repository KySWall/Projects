#EmployeeClassOutput
#Creates and outputs employee objects
#Kyle Wall


#Imports the class program
import EmployeeClass

#Function to runt the whole thing
def main():
    #Create three employee objects
    employee1 = EmployeeClass.Employee('name', 'id', 'department', 'title')
    employee2 = EmployeeClass.Employee('name', 'id', 'department', 'title')
    employee3 = EmployeeClass.Employee('name', 'id', 'department', 'title')

    #create three Employee objects for each part of data
    #This is employee 1
    employee1.set_name('Susan Meyers')
    employee1.set_id('47899')
    employee1.set_department('Accounting')
    employee1.set_title('Vice President')
    
    #This is employee 2
    employee2.set_name('Mark Jones')
    employee2.set_id('39119')
    employee2.set_department('IT')
    employee2.set_title('Programmer')
    
    #This is employee 3
    employee3.set_name('Joy Rogers')
    employee3.set_id('81774')
    employee3.set_department('Manufacturing')
    employee3.set_title('Engineer')

    #Prints out the employee data
    print()
    print(employee1)
    print()
    print(employee2)
    print()
    print(employee3)


main()
