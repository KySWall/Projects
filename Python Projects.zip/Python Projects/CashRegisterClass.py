#CashRegister
#Create a program that keeps track of inventory and pice of clothing products
#Kyle Wall

#import retailitem class
import RetailItemClass

class CashRegister:
    #intialize an empty list hold our items

    def __init__(self):
        self.__items = []

    #Method that adds items to the list
    def purchase_item(self, retailitem):
        self.__items.append(retailitem)
        print('The item was added to the register.')
        

    #Method that returns cost of items
    def get_total(self):
        total = 0.0
        for item in self.__items:
            total = total + item.get_price()
        return total

    #Method that displays number in iventory
    def show_items(self):
        for item in self.__items:
            print(item.get_description())
            print('Inventory: ' + str(item.get_inventory()))
            print(str(item.get_price()))
            print()

    #Clears interal list
    def clear_register(self):
        for item in self.__items:
            self.__items.remove(item)








            
