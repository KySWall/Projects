#BuildingCustomExceptionsMain
#The output for the 'BuildingCustomException' IceCream class
#Kyle Wall

#This is the 'IceCreamStore'

#Import the CustomException prrogram and class
from CustomException import IceCream


#Custom exceptions
class Error(Exception):
    pass

class FlavorError(Error):
    pass

class ScoopsError(Error):
    pass


#Function to run the program
def main():

    #Create items for the ice cream
    flavorChoices = IceCream('Vanilla', 'Chocolate', 'Strawberry', 'Mint', 'Pistachio', 'Spumoni')
    numberOfScoops = IceCream('1', '2', '3')
    coneOrBowl = IceCream('Cone', 'Bowl')

    while True:
        userFlavorChoice = input('Enter a ice cream flavor: ')
        userNumberOfScoops = int(input('Enter a number of scoops: '))
        userConeOrBowl = input('Would you like a cone or bowl? ')

        try:
            
        


main()
    
    
