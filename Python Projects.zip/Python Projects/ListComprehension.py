    #ListComprehension
#Between 2 integers, print all #'s inbetween, all sqaures, even and odds
#Kyle Wall (09/16/2022)


User_number_1 = int(input("Enter first number: "))

User_number_2 = int(input("Enter second number: "))

NumberList = [*range(User_number_1, User_number_2 + 1)] #List of possible numbers

print(NumberList[:]) #Prints whole number list

SquareList = [x**2 for x in NumberList] #Squares all numbers in list

print(SquareList) #Prints squared list

for e in range(User_number_1, User_number_2 + 1): #Create new list from user input
    if e %2==0: #Modulus of 2, removes odd numbers
        print(e, end = " ",) #Prints list

print() #seperation for readability

for odd in range(User_number_1, User_number_2 + 1):
    if odd %2!=0: #Not equal to modulus of 2, removes even numbers
        print(odd, end = " ") #Prints list
