#EmployeeAndProductionWorkerClass
#Create a class that keeps data attributes for names and number
#Then make a subclass that contains shift #'s and hourly pay

#Creating a new employee class, different from the previous one
#Kyle Wall

#Creating a new employee class
class Employee:
    #Initialize name and employee number
    def __init__(self, name, number):
        self.__name = name
        self.__empNum = number
    #Set and get attributes
    def set_name(self, name):
        self.__name = name

    def get_name(self):
        return self.__name

    def set_empNum(self, number):
        self.__empNum = number

    def get_empNum(self):
        return self.__empNum

#Creating a production worker subclass
class ProductionWorker(Employee):
    
    #Initalize shift and hourly pay
    def __init__(self, name, number, shiftNum, hourlyPay):
        if shiftNum == 1 or shiftNum == 2 or shiftNum == 3:
            self.__shift = shiftNum
        else:
             print('The shift number should be 1, 2, or 3.')
        self.__pay = float(hourlyPay)
        Employee.__init__(self, name, number)

    def set_shiftNum(self, shiftNum):
        if shiftNum == 1 or shiftNum == 2 or shiftNum == 3:
            self.__shift = shiftNum
        else: #For some reason isn't working
            print('The shift number should be 1, 2, or 3.')

    def get_shiftNum(self):
        if self.__shift == 1:
            return 'Day Shift'
        elif self.__shift == 2:
            return 'Night Shift'
        elif self.__shift == 3:
            return 'Weekend'
        else: #For some reason isn't working 
            print('The shift number should be 1, 2, or 3.')

    def set_hourlyPay(self, hourlyPay):
        self.__pay = float(hourlyPay)

    def get_hourlyPay(self):
        return format(self.__pay, ',.2f')
    
    #Dont think I'm applying this correctly
    def __str__(self):
        return 'Name: ' + self.__name + \
               '\nID number: ' + self.__empNum + \
               '\nDepartment: ' + self.__shift + \
               '\nTitle: ' + self.__pay
