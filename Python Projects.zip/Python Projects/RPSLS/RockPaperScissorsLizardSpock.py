#RockPaperScissorsLizardSpock
#Create this game, giving the peogram a random choice
#Kyle Wall (09/30/2022)

import random #Import a random function later by using random.randrange

def numberToChoice(number): #Convert a number to a choice
    if number == 0:
        return "Rock"
    elif number == 1:
        return "Spock"
    elif number == 2:
        return "Paper"
    elif number == 3:
        return "Lizard"
    elif number == 4:
        return "Scissors"
    else:
        print("Error")

    
def choiceToNumber(choice): #Convert a choice to a number
    if choice == "Rock":
        return 0
    elif choice == "Spock":
        return 1
    elif choice == "Paper":
        return 2
    elif choice == "Lizard":
        return 3
    elif choice == "Scissors":
        return 4
    else:
        print("Error")

def wereGaming(user_input): #Attempts to selcet a winner
    
    playerNumber = choiceToNumber(user_input)
    pythonNumber = random.randrange(0,5)

    if (pyhtonNumber + 1) % 5 == playerNumber:
        print "Player wins!"
    elif (pythonNumber + 2) % 5 == playerNumber:
        print "Player wins!"
    elif pythonNumber == playerNumber:
        print "Player and computer tie!"
    else:
        print "Computer wins!"



    #pythonChoice = numberToChoice(pythonNumber);
    #print("Python chooses: ") + pythonChoice
    #difference = (pythonNumber - playerNumber)%5
    #if (difference == 1 or difference == 2):
    #    print("Python Wins!")
    #elif (difference == 4 or difference == 3):
    #    print("Player Wins!")
    #elif (difference == 0):
    #    print("Pyhton and the Player tie!")




