#RockPaperScissorsLizardSpock
#Create this game, giving the program a random choice
#Kyle Wall (09/30/2022)

import random #Import a random function later by using random.randrange

#Gets users input
userInput = input("Enter a choice:(Rock, Paper, Scissors, Lizard, Spock): ")

#List of possible moves
possibleMoves = ["Rock", "Paper", "Scissors", "Lizard", "Spock"]
#Python chooses random
pythonAction = random.choice(possibleMoves)

#Prints the choices
print("You chose", userInput, " - Python chose", pythonAction) 

#Who's winning
if userInput == pythonAction:
    print("It's a tie!")
elif userInput == "Rock":
    if pythonAction == "Scissors":
        print("Rock smashes scissors! You win!")
    elif pythonAction == "Spock":
        print("Spock vaporizes rock! You lose.")
    elif pythonAction == "Lizard":
        print("Rock smashes lizard! You win")
    else:
        print("Paper covers rock! You lose.")
elif userInput == "Paper":
    if pythonAction == "Rock":
        print("Paper covers rock! You win!")
    elif pythonAction == "Spock":
        print("Paper disproves Spock! Ypu win!")
    elif pythonAction == "Lizard":
        print("Lizard eats paper! You lose!")
    else:
        print("Scissors cuts paper! You lose.")
elif userInput == "Scissors":
    if pythonAction == "Paper":
        print("Scissors cuts paper! You win!")
    elif pythonAction == "Spock":
        print("Spock smashes scissors! You lose!")
    elif pythonAction == "Lizard":
        print("Scissors decapitates lizard! You win!")
    else:
        print("Rock smashes scissors! You lose.")
elif userInput == "Lizard":
    if pythonAction == "Paper":
        print("Lizard eats paper! You win!")
    elif pythonAction == "Spock":
        print("Lizard poisons Spock! You win!")
    elif pythonAction == "Scissors":
        print("Scissors decapitates lizard! You lose!")
    else:
        print("Rock smashes lizard! You lose!")
elif userInput == "Spock":
    if pythonAction == "Paper":
        print("Paper disproves Spock! You lose!")
    elif pythonAction == "Lizard":
        print("Lizard poisons Spock! You lose!")
    elif pythonAction == "Scissors":
        print("Spock smashes scissors! You Win!")
    else:
        print("Spock vaporizes rock! You Win!")





        
