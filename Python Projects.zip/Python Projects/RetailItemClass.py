#RetailItemClass
#Create a class that will fetch and return data about clothing
#Kyle Wall

#Create a class named RetialItem
class RetailItem:

    #Ititialize the attributes of the items
    def __init__ (self, description, inventory, price):
        self.__description = description
        self.__inventory = inventory
        self.__price = price

    #Set the description, inventory, and price
    def set_description(self, description):
        self.__description = description

    def set_inventory(self, inventory):
        self.__inventory = inventory

    def set_price(self, price):
        self.__price = price

    #Return the decription, inventory, and price
    def get_description(self):
        return self.__description

    def get_inventory(self):
        return self.__inventory

    def get_price(self):
        return self.__price

    #Return the data into a cleaner format
    def __str__(self):
         return 'Description: ' + self.__description + '\n' + \
                'Units in Inventory: ' + self.__inventory + '\n' + \
                'Price: ' + self.__price
          
    
