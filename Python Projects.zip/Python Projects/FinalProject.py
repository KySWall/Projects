#FinalProject
#Create a inventory management system
#Kyle Wall

import os #Lets me read and write in a file. Also within the start file.
import fileinput #Lets me iterate over multiple lines within the file.
#Also adds some helper functions when working with a file.


#Within the start file
def menuDisplay(): #Premade menu to navigate 
    print ('=============================')
    print ('= Inventory Management Menu =')
    print ('=============================')
    print ('(1) Add New Item to Inventory')
    print ('(2) Remove Item from Inventory')
    print ('(3) Update Inventory')
    print ('(4) Search Item in Inventory')
    print ('(5) Print Inventory Report')
    print ('(99) Quit')
    CHOICE = int(input("Enter choice: ")) #This takes in the user's input. Which then gets sent to menuSelection(CHOICE)
    menuSelection(CHOICE) #Lets user make a choice of which function they want to use


#Within the start file
def menuSelection(CHOICE): #Navigate the user to where they want to go based on their input
    if CHOICE == 1:
        addInventory() #If user enters 1 -> Send them to the addInventory() Function 
    elif CHOICE == 2:
        removeInventory() #If user enters 2 -> Send them to the removeInventory() Function
    elif CHOICE == 3:
        updateInventory() #If user enters 3 -> Send them to the updateInventory() Function
    elif CHOICE == 4:
        searchInventory() #If user enters 4 -> Send them to the searchInventory() Funciton 
    elif CHOICE == 5:
        printInventory() #If user enters 5 -> Send them to the printInventory() Function 
    elif CHOICE == 99:
        exit()
    else: #If they don't enter a number 1-5(98,99) then give them this "ERROR"
        print ('Please choose an existing option')


def addInventory():
    print('Adding Inventory') #Makes the menu pretty and more legiable.
    print('=================')
    item_description = str(input('Enter the name of the item: ')) #User's input for the name of the item to be added
    item_quantity = input('Enter the quantity of the item: ') #User's input for the quantity of the new item
    with open ('Inventory.txt', 'a') as f: #Opens the Inventory.txt file in append mode
        f.write(item_description)
        f.write('\n') #Appends the user's input for the name then make a new line
        f.write(item_quantity)
        f.write('\n') #Appends the user;s inputed quantity then makes a new line
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else: #After input, lets the user choose to exit the program or go back to the menu
        exit()


def removeInventory():
    print('Removing Inventory') #Makes the menu pretty and more legiable.
    print('===================')
    item_description = input('Enter the item name to remove from inventory: ') #User's input for the name of the item to be removed
    file = fileinput.input('Inventory.txt', inplace = True) #This essentially means that the data that is being modied in being modified inplace.
    for line in file:                                       #Meaning that the data enterd will return nothing.
         if item_description in line:
             for i in range(1): #Removes the inputed line(The users input/name of the item) then also removes the line after which is the quantity
                 next(file, None)
         else: #Removes all null/empty space
             print(line.strip('\n'), end='\n')
    item_description
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else: #After input, lets the user choose to exit the program or go back to the menu
        exit()


def updateInventory():
    print('Updating Inventory') #Makes the menu pretty and more legiable.
    print('===================')
    item_description = input('Enter the item to update: ') #User's input for the name of the item to be updated
    item_quantity = int(input('Enter the updated quantity. Enter 5 for additional or -5 for less: ')) #User's change to the quantity
    with open('Inventory.txt', 'r') as f: #Open's the Inventory.txt file in read mode
        filedata = f.readlines() #Varible to read the lines of the file
    replace = ""
    line_number = 0
    count = 0
    f = open('Inventory.txt','r') #Re-open file in read mode
    file = f.read().split('\n') #Splits the the lines of the file into a list of items
    for i, line in enumerate(file): #Enumerate the new list of items 
        if item_description in line:
            for b in file[i+1:i+2]:
                value = int(b) #Go through the list until it finds something that matches to the user's input
                change = value + (item_quantity)
                replace = b.replace(b, str(change)) #Replace the quanity with - (Original quantity + (Change to quantity) = Updated quantity)
                line_number = count
            count = i + 1      
    f.close()
    filedata[count] = replace + '\n'
    with open('Inventory.txt', 'w') as f: #Open the Inventory.txt file in write mode
        for line in filedata:
            f.write(line)    #Write in the new difference in the quantity
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else: #After input, lets the user choose to exit the program or go back to the menu
        exit()


def searchInventory():
    print('Searching Inventory') #Makes the menu pretty and more legiable.
    print('====================')
    item_description = input('Enter the name of the item: ')#User's input for the name of the item to be searched
    f = open('Inventory.txt', 'r') #Open Inventory.txt in read mode
    search = f.readlines() #Read the whole document
    f.close
    for i, line in enumerate(search): #Turn the file's contents into a list of items and mark them to make it easier to interact with the file. 
        if item_description in line:  #Then search for a "item" that matches the inputed string
            for b in search[i:i+1]:
                print('Item:     ', b, end='')
            for c in search[i+1:i+2]:
                print('Quantity: ', c, end='') 
                print('----------')
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else: #After input, lets the user choose to exit the program or go back to the menu
        exit()


#Withtin the start file
def printInventory(): 
    InventoryFile = open('Inventory.txt', 'r') #Opens the Inventory.txt file in read mode
    item_description = InventoryFile.readline()
    print ('Current Inventory') #Makes the menu pretty and more legiable.
    print ('-----------------')
    while item_description != '':
        item_quantity = InventoryFile.readline() #Lists out all of the text within the Inventory.txt file
        item_description = item_description.rstrip('\n')
        item_quantity = item_quantity.rstrip('\n')
        print ('Item:     ' , item_description)
        print ('Quantity: ' , item_quantity) #Makes the list of information more legiable and easier to read
        print ('----------')
        item_description = InventoryFile.readline()
    InventoryFile.close() #Closes the Inventory.txt file
    CHOICE = int(input('Enter 98 to continue or 99 to exit: '))
    if CHOICE == 98:
            menuDisplay()
    else: #After input, lets the user choose to exit the program or go back to the menu
        exit()


menuDisplay() #Execute function




