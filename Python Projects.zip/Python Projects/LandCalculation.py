#LandCalculation
#Kyle Wall (09/02/2022)
#Declaring and calculating a variable based off of user input

#Proposes question for user to enter than calculates. 
number_of_feet = float(input("Enter a number of square feet in the tract: "))
acres = number_of_feet / 43560
print(number_of_feet, "feet is equal to", round(acres, 2))
