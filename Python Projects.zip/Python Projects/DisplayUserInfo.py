#DisplayUserInfo
#Kyle Wall (09/02/2022)
#Asks for user input, than outputs info givin 

#Input commands that ask for user info
first_name = str(input("Enter your first name: "))
last_name = str(input("Enter your last name: "))
month = str(input("Birth Month: "))
day = str(input("Birth Day(1-31): "))
year = str(input("Birth Year(YYYY): "))
print(first_name, last_name, "was born", month, day + ",", year + ".")
#Displays the info the user gave
