#PrintingAndFormatting
#Kyle Wall (08/24/2022)
#Formatting within the print() function 

print("The quick brown fox\njumps over\nthe lazy dog")
print() #Seperation for readability while the program is running
print("I just made $1,123,456.75 in the lottery!")
print()
print("I've seen it all and I'm still in shock!")
print()
print("1).Item 1", "2).Item 2", "3).Item 3", sep="\n")
print()
print("Programming", "Essentials", sep="***", end="***")
print("in", "Python", sep="...")
