#KineticEnergy
#Calculate an objects kinetic energy from it's mass and velocity
#Kyle Wall (09/23/2022)

def kinetic_energy(m, v): #Kinetic energy function
    KE = 0.5*m*v**2 #Kinetic energy formula
    return KE

def main(): #Function that asks user input, and gives output
    #User input
    m = int(input("Enter the object's mass in kilogrmas (kg): "))
    v = int(input("Enter the object's velocity in meter per second(m/s): "))
    #Delcare user input back to them
    print("The object has a mass of", m, "kilograms, a velocity of", v, "meters per second")
    #Outputs calculation from user input
    print("The object's kinetic energy is", kinetic_energy(m, v), "joules")
#Calls the main function 
main()
