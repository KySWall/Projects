#StringManipulation
#Changer the user's inputed string in multiple ways.
#Kyle Wall 

#Gets user input
userInput = input("Enter a string: ")

#Capitalize the string (Cant get 2nd sentence to capitalize)
print("Here is the string with the first letter capitalized: ", userInput.capitalize())

#String in all caps
print("Here is the string in upper case: ", userInput.upper())

#String in lower case
print("Here is the string in lower case: ", userInput.lower())

#Each word is capitalized
print("Here is the string in title case: ", userInput.title())
