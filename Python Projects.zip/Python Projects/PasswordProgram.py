#PasswordProgram
#Create a password authentication program, 3 attempts
#Kyle Wall

#Keeps track of attempts
count = 3

while count > 0:
    #Asks for user input
    passwordInput = input("Please enter your password: ")
    #If the password is correct break the loop
    if passwordInput == "MyPassword":
        print("Authentication Succesful!")
        break
    #User gets 3 attempts 
    else:
        count -= 1
        print("Password incorrect! You have", count ,"more attempts!")
        continue
#If the user uses all 3 attempts the loop ends and they can input no longer
if count == 0:
     print("User account is now locked")
