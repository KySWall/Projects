#BuildingCustomExceptions
#Icecream shop class, but with custom exceptions
#Kyle Wall

#Createing a class
class IceCream:

    #Intialize data
    def __init__ (self, flavor, scoops, lattice):
        self.__flavor = flavor
        self.__scoops = scoops
        self.__lattice = lattice

    #Set the attributes
    def set_flavor(self, flavor):
        self.__flavor = flavor

    def set_scoops(self, scoops):
        self.__scoops = scoops

    def set_lattice(self, lattice):
        self.__lattice = lattice

    #Return the attributes
    def get_flavor(self):
        return self.__flavor

    def get_scoops(self):
        return self.__scoops

    def get_lattice(self):
        return self.__lattice

    #Return the data into a cleaner format
    def __str__(self):
        return 'Enter a flavor: ' + self.__flavor + '\n' + \
               'Number of scoops: ' + self.__scoops + '\n' + \
               'Cone or bowl? ' + self.__lattice



















        
