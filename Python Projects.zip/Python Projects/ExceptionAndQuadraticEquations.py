#ExceptionAndQuadraticEquations
#Be able to ask for the varibale to solve a quadratic equasion
#Kyle Wall (10/14/2022)

#Importing complex math
import cmath

#Getting user input to solve equasion
#Looping so if there is an error, it gives back user control
while True:
    try:
        a = float(input("Enter a value for a: "))
        b = float(input("Enter a value for b: "))
        c = float(input("Enter a value for c: "))
    except ValueError: #If value is not a float
        print("Please enter a float, not a string")
        continue
#Not letting the user divide by 0
    if a == 0:
        print("Input correct numbers for quadratic equasion")
    else:
        break

#Calculate discriminant
d = (b**2)-(4*a*c)

#Finding the solutions
solution1 = (-b-cmath.sqrt(d))/(2*a)
solution2 = (-b+cmath.sqrt(d))/(2*a)

#Printing the solutions
print("The discriminant is equal to: ", d)
print("The solution are", solution1, "and ", solution2)
#I was having issue simplifying the solutions 
