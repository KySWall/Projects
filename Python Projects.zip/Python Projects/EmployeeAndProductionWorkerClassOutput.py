#EmployeeAndProductionWorkerClassOutput
#Takes in user input to create employee objects
#Kyle Wall

#Imports the class program
import EmployeeAndProductionWorkerClass

def main():
    #Create some variables for the production worker
    proWorkerName = ' '
    proWorkerID = ' '
    proWorkerShift = 0
    proWorkerPay = 0.0

    #Take in user input to create production worker object
    proWorkerName = input('Enter Workers Name: ')
    proWorkerID = int(input('Enter ID number: '))
    proWorkerShift = int(input('Enter Shift Number: '))
    proWorkerPay = float(input('Enter the Workers Pay Rate; '))

    Worker = EmployeeAndProductionWorkerClass.ProductionWorker(proWorkerName, proWorkerID, proWorkerShift, proWorkerPay)

    #Display production worker's information
    print()
    print('Production Worker Information')
    print(' -------------------------------------- ')
    print('Name: ', Worker.get_name())
    print('ID Number: ', Worker.get_empNum())
    print('Shift Number: ', Worker.get_shiftNum())
    print('Hourly Pay: ', Worker.get_hourlyPay())

main()
