#RemoveEvenNumbers
#Print a list of even numbers in accordence with user input
#Kyle Wall due(09/16/2022)


USER_NUMBER = int(input("Enter a number: ")) 
numberList = [*range(0, USER_NUMBER)] #List of possible numbers
 
for e in numberList:
    if (e %2==0): #If a number is a modulus of 2 (Even)
       numberList.remove(e) #Remoce said number 

print(numberList) #Prints all odd numbers between input





#What i was tring for a long while (Incorrect)

#while True:
#    USER_NUMBER = int(input("Enter a number (0-100): "))
#       if USER_NUMBER >= 101:
#            break
#       else for e in numberList:
#           if (e %2==0):
#               numberList.remove(e)
            
