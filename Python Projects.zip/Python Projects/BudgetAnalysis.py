#BudgetAnalysis
#Declare variables to state and store various budget amounts.
#Kyle Wall (09/09/2022)

buget = 0.0
difference = 0.0
expense = 1.0 #1.0 intializes the 'while' loop
total = 0.0

#Get users budget
budget = float(input("Enter the amount budgeted for the month: "))

#Total amount spent by the user
while expense != 0:
    expense = float(input("Enter and expense (0 to quit): "))
    total += expense

#Reinstates the amount the user is budgeting
print("Budgeted: $", format(budget, ",.2f"))
#States the amount the user spent in expense
print("Spent: $", format(total, ",.2f"))

#Determines if the user is over or under budget
if total < budget:
    difference = budget - total
    print("You are $", difference, "under budget.")
elif total > budget:
    difference = budget - total
    print("You are $", difference, "over budget.")
else:
    print("You were right on budget!")



