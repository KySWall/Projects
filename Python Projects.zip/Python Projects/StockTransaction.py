#StockTransaction
#Kyle Wall (09/02/2022)
#"Hard-coded" problem solvinf that will get displayed

amountpaid = 40.00 * 2000 #Calculation for how much was spent to buy stock.
print("Amount paid for stock: ", amountpaid)
commissionpaid = amountpaid * .03 #Calculation for the commission. 
print("Commision paid on the purchase: ", round(commissionpaid, 2))
amountsold = 42.75 * 2000 #Calculation for how much the stock sold for.
print("Amount the stock sold for: ", amountsold)
commissionsold = amountsold * .03 #Calculaiton for the 2nd commission
print("Commision paid on the sale: ", round(commissionsold, 2))
profit = amountsold - amountpaid - commissionpaid - commissionsold #Profit calculation
print("Profits = ", profit)
