#PrimeNumberGenerator
#Print all prime numbers between 2 and enterd numberd
#Kyle Wall (09/16/2022)


UserNumber = int(input("Enter a number: "))

NoPrimes = [a for b in range(2, UserNumber) for a in range(b*2, UserNumber, b)]

ListofPrimes = [x for x in range(2, UserNumber) if x not in NoPrimes]
print(ListofPrimes)
