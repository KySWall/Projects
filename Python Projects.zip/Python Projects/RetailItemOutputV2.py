#RetialItemOutputV2
#Cretes and outputs item attributes representing a store
#Kyle Wall


#Imports the class programs
from RetailItemClass import RetailItem
from CashRegisterClass import CashRegister

#Function to run the whole thing
def main():
    
    #Create 3 item objects
    item1 = RetailItem('Jacket', 12, 59.95)
    item2 = RetailItem('Designer Jeans', 40, 34.95)
    item3 = RetailItem('Shirt', 20, 24.95)
    #Format "selection screen" and post item info
    print('Description\t\tIn Inventory\t\tPrice')
    print('--------------------------------------------------------')
    print(item1.get_description() + '\t\t\t' + str(item1.get_inventory()) + '\t\t\t' + '$' + str(item1.get_price()))
    print(item2.get_description() + '\t\t' + str(item2.get_inventory()) + '\t\t\t' + '$' + str(item2.get_price()))
    print(item3.get_description() + '\t\t\t' + str(item3.get_inventory()) + '\t\t\t' + '$' + str(item3.get_price()))

    register = CashRegister()
    #Loop to let customer select multiple items
    checkout = 'y'
    while checkout.upper() == 'Y':
        print()
        print('Please enter a number to select which item you want to purchase.')
        print('1 = Jacket, 2 = Designer Jeans, 3 = Shirt')
        itemchoice = int(input('Please enter a item number: '))

        if itemchoice == 1:
            register.purchase_item(item1)
        elif itemchoice == 2:
            register.purchase_item(item2)
        elif itemchoice == 3:
            register.purchase_item(item3)
        else:
            print('Item not avalable.')
    #Lets the user contine if they want
        checkout = input('Do you want to continue? (Y/N): ')
    #Prints result (Don't know how to lower inventory)
    print()
    print('The items in the cash register are')
    print('------------------------------------')
    register.show_items()
    print('The price is')
    print('$' + format(register.get_total(), ',.2f'))
    
main()
