import pygame
import random

# Initialize Pygame
pygame.init()

# Set up the game window
window_width = 400
window_height = 400
window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption("Snake Game")

# Set up the colors
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)

# Set up the snake and food
snake_size = 10
snake_x = window_width / 2
snake_y = window_height / 2
food_x = round(random.randrange(0, window_width - snake_size) / 10.0) * 10.0
food_y = round(random.randrange(0, window_height - snake_size) / 10.0) * 10.0

# Set up the clock
clock = pygame.time.Clock()

# Set up the game loop
game_over = False
while not game_over:

    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True

    # Move the snake
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        snake_x -= snake_size
    if keys[pygame.K_RIGHT]:
        snake_x += snake_size
    if keys[pygame.K_UP]:
        snake_y -= snake_size
    if keys[pygame.K_DOWN]:
        snake_y += snake_size

    # Draw the snake and food
    window.fill(black)
    pygame.draw.rect(window, red, [food_x, food_y, snake_size, snake_size])
    pygame.draw.rect(window, white, [snake_x, snake_y, snake_size, snake_size])

    # Check for collision with the food
    if snake_x == food_x and snake_y == food_y:
        food_x = round(random.randrange(0, window_width - snake_size) / 10.0) * 10.0
        food_y = round(random.randrange(0, window_height - snake_size) / 10.0) * 10.0

    # Update the screen
    pygame.display.update()

    # Set the game's FPS
    clock.tick(30)

# Quit Pygame
pygame.quit()
