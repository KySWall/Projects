import pygame
import random

# Initialize Pygame
pygame.init()

# Set the screen size
screen_width = 640
screen_height = 480
screen = pygame.display.set_mode((screen_width, screen_height))

# Set the game variables
snake_size = 10
snake_speed = 15
font = pygame.font.SysFont("comicsansms", 20)

# Define the colors
white = (255, 255, 255)
black = (0, 0, 0)
green = (0, 255, 0)
red = (255, 0, 0)

# Define the Snake class
class Snake:
    def __init__(self):
        self.x = screen_width/2
        self.y = screen_height/2
        self.direction = "up"
        self.body = []
        self.length = 1

    def move(self):
        if self.direction == "up":
            self.y -= snake_size
        elif self.direction == "down":
            self.y += snake_size
        elif self.direction == "left":
            self.x -= snake_size
        elif self.direction == "right":
            self.x += snake_size

        # Add the new head position to the body
        self.body.insert(0, (self.x, self.y))

        # Remove the tail if the snake is longer than its length
        if len(self.body) > self.length:
            self.body.pop()

    def draw(self):
        for pos in self.body:
            pygame.draw.rect(screen, green, (pos[0], pos[1], snake_size, snake_size))

    def eat(self, food_pos):
        if self.x == food_pos[0] and self.y == food_pos[1]:
            self.length += 1
            return True
        return False

    def collide(self):
        # Check if the snake hits the wall
        if self.x < 0 or self.x >= screen_width or self.y < 0 or self.y >= screen_height:
            return True

        # Check if the snake hits itself
        for pos in self.body[1:]:
            if self.x == pos[0] and self.y == pos[1]:
                return True

        return False

# Define the Food class
class Food:
    def __init__(self):
        self.x = random.randint(0, screen_width-snake_size)
        self.y = random.randint(0, screen_height-snake_size)

    def draw(self):
        pygame.draw.rect(screen, red, (self.x, self.y, snake_size, snake_size))

# Create the objects
snake = Snake()
food = Food()

# Game loop
game_over = False
while not game_over:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP and snake.direction != "down":
                snake.direction = "up"
            elif event.key == pygame.K_DOWN and snake.direction != "up":
                snake.direction = "down"
            elif event.key == pygame.K_LEFT and snake.direction != "right":
                snake.direction = "left"
            elif event.key == pygame.K_RIGHT and snake.direction != "left":
                snake.direction = "right"

    # Move the snake
    snake.move()
