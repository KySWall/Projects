import pygame
import random

# Initialize Pygame
pygame.init()

# Set up the game window
window_width = 500
window_height = 500
window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption("Snake Game")

# Set up the snake and food
snake_block_size = 10
snake_speed = 15
snake_list = []
snake_length = 1
snake_head = [window_width/2, window_height/2]
food_x = round(random.randrange(0, window_width - snake_block_size) / 10.0) * 10.0
food_y = round(random.randrange(0, window_height - snake_block_size) / 10.0) * 10.0

# Set up the colors
white = (255, 255, 255)
black = (0, 0, 0)
red = (213, 50, 80)
green = (0, 255, 0)

# Set up the game loop
game_over = False
clock = pygame.time.Clock()

# Define a function to display the snake on the screen
def draw_snake(snake_block_size, snake_list):
    for x in snake_list:
        pygame.draw.rect(window, green, [x[0], x[1], snake_block_size, snake_block_size])

# Run the game loop
while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                snake_head[0] -= snake_block_size
            elif event.key == pygame.K_RIGHT:
                snake_head[0] += snake_block_size
            elif event.key == pygame.K_UP:
                snake_head[1] -= snake_block_size
            elif event.key == pygame.K_DOWN:
                snake_head[1] += snake_block_size

    # Check if the snake hits the wall
    if snake_head[0] >= window_width or snake_head[0] < 0 or snake_head[1] >= window_height or snake_head[1] < 0:
        game_over = True

    # Move the snake
    snake_head_copy = snake_head[:]
    snake_list.append(snake_head_copy)
    if len(snake_list) > snake_length:
        del snake_list[0]

    # Check if the snake hits itself
    for x in snake_list[:-1]:
        if x == snake_head:
            game_over = True

    # Check if the snake eats the food
    if snake_head[0] == food_x and snake_head[1] == food_y:
        food_x = round(random.randrange(0, window_width - snake_block_size) / 10.0) * 10.0
        food_y = round(random.randrange(0, window_height - snake_block_size) / 10.0) * 10.0
        snake_length += 1

    # Fill the background color
    window.fill(black)

    # Draw the food
    pygame.draw.rect(window, red, [food_x, food_y, snake_block_size, snake_block_size])

    # Draw the snake
    draw_snake(snake_block_size, snake_list)

    # Update the display
    pygame.display.update()

    # Set the game speed
    clock.tick(snake_speed)

# Quit Pygame
pygame.quit()
