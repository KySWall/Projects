#RetialItemOutput
#Cretes and outputs item attributes
#Kyle Wall


#Imports the class programs
import RetailItemClass
import CashRegister

#Function to run the whole thing
def main():
    #Create 3 item objects
    item1 = RetailItemClass.RetailItem('description', 'units in inventory', 'price')
    item2 = RetailItemClass.RetailItem('description', 'units in inventory', 'price')
    item3 = RetailItemClass.RetailItem('description', 'units in inventory', 'price')

    #Create 3 item obejcts, then their attributes
    #This is item 1
    item1.set_description('Jacket')
    item1.set_inventory('12')
    item1.set_price('$59.95')

    #This is item 2
    item2.set_description('Designer Jeans')
    item2.set_inventory('40')
    item2.set_price('$34.95')

    #This is item 3
    item3.set_description('Shirt')
    item3.set_inventory('20')
    item3.set_price('$24.95')

    #Prints out the item data
    print()
    print(item1)
    print()
    print(item2)
    print()
    print(item3)
        












main()
