#StadiumSeating
#Calculate the cost of seat purchased at different price points
#Kyle Wall (09/23/2022)

def main(): #Calls back  main() function
    sectionA, sectionB, sectionC, sectionD = get_input() #Calls get_input function
    total_income(sectionA, sectionB, sectionC, sectionD) #Calls total_income function

def get_input(): #This function collects input from user
    sectionA = int(input("Enter the number of seats in Section A ($25): "))
    sectionB = int(input("Enter the number of seats in Section B ($20): "))
    sectionC = int(input("Enter the number of seats in Section C ($15): "))
    sectionD = int(input("Enter the number of seats in Section D ($10): "))
    return (sectionA, sectionB, sectionC, sectionD)
    
def total_income(sectionA, sectionB, sectionC, sectionD):
    salesA = sectionA*25
    salesB = sectionB*20 #This function calculations for seat price
    salesC = sectionC*15
    salesD = sectionD*10
    total_sales = salesA + salesB + salesC + salesD #Calculats total
    #Output for how much income seats made
    print("Income from Section A seats: $", format(salesA, ',.2f'))
    print("Income from Section B seats: $", format(salesB, ',.2f')) 
    print("Income from Section C seats: $", format(salesC, ',.2f'))
    print("Income from Section D seats: $", format(salesD, ',.2f'))
    print("Total income sales is: $", format(total_sales, ',.2f'))


main()
