#RemoveOddNumbers
#Remove odd numbers from a list in accodence with user input
#Kyle Wall (09/16/2022)

USER_NUMBER = int(input("Enter a number: ")) 
numberList = [*range(0, USER_NUMBER)] #List of possible numbers
 
for e in numberList:
    if (e %2!=0): #If a number is not a modulus of 2 (Odd)
       numberList.remove(e) #Remoce said number 

print(numberList) #Prints all odd numbers between input

