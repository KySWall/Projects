#DayOfTheWeek
#Kyle Wall (09/09/2022)
#Using if/elif/else 

#Prompts user with a question, asking for an answer
dayofweek = int(input("Enter a number (1-7) for a day of the week: "))

if dayofweek == 1:
    print("Monday")
elif dayofweek == 2:
    print("Tuesday")
elif dayofweek == 3:
    print("Wednesday")
elif dayofweek == 4:
    print("Thursday")
elif dayofweek == 5:
    print("Friday")
elif dayofweek == 6:
    print("Saturday")
elif dayofweek == 7:
    print("Sunday")
else:
    print("Error! A number 1-7 please!")
#Self-made error to get the user to enter a number within the correct range

    



